﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AIMLbot;

namespace AI_ChatBot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bot AI = new Bot();
            AI.loadSettings(); //It will load default settings from its config
            AI.loadAIMLFromFiles(); //With this line it will load aIML files from its AIML folder
            AI.isAcceptingUserInput = false; //disables user input for now
            User myUser = new User("Username Here", AI); //Adds the User through AI/Bot
            AI.isAcceptingUserInput = true; //User Input is now enabled
            Request r = new Request(textBox1.Text, myUser, AI); //requests the response from AIML folder
            Result res = AI.Chat(r); //gets result
            textBox2.Text = "AI Bot: " + res.Output; //writes the result of textbox1 response to textbox2 text
        }
    }
}
